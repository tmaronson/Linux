
cat $1 | awk '{if (NF < 4) print "Not all scores are available for " $1;}'