#!/bin/sh
read total
count=0
sum=0
while [ $count -lt $total ]
do
    read num
    sum=$((sum + num))
    count=$((count + 1))
done
ave=`echo "$sum/$total" | bc -l`
printf "%.3f" $ave